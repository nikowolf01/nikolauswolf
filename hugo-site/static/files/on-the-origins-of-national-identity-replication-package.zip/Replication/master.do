clear all
set matsize 1000
set scheme lean2

global root     "~/Dropbox/04 Names/Journal of Comparative Economics/Replication"

global data 	"$root/Data"
global code 	"$root/Code"
global output 	"$root/Output"

*Figure 1: Map (see paper)

*Figure 2
do "$code/figure 2"

*Figure 3
do "$code/figure 3"

*Table 1: Table on main events

*Table 2 (the code generates the descriptives, w/o a .tex)
do "$code/table 2"

*Table 3 (the .dta includes the descriptives in Table 3)
use "$data/data_tab3", clear

*Table 4 (the code generates the descriptives, w/o a .tex)
do "$code/table 4"

*Table 5 (the code generates the descriptives, w/o a .tex)
do "$code/table 5"

*Table 6
do "$code/table 6"
