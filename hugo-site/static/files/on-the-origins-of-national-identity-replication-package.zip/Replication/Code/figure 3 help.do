capture program drop reg_figure3

* define program 
program reg_figure3
	
	*** inputs & decade level regression 
	
	* specify inputs with respective data types (varname = dependent variable)
	syntax varname, color(string) graphtitle(string) graphname(string)
	
	local dependent_variable `varlist'
		
		
		/* Notes: 	- the result of this regression are the point estimates 
					with their decade specific confidence intervals in figure 3 */
		
		areg `dependent_variable' ///
		treat_x_1810-treat_x_1813 ///
		treat_x_1815-treat_x_1821 ///
		year1810-year1813 ///
		year1815-year1821 ///
		, ///
		cluster(place_id) absorb(place)
		
	boottest treat_x_1810 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	

      scalar ll11 = r(CI)[1,1]
      scalar ul11 = r(CI)[1,2]

	boottest treat_x_1811 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)
	
   scalar ll21 = r(CI)[1,1]
   scalar ul21 = r(CI)[1,2]

	boottest treat_x_1812 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
	
	 scalar ll31 = r(CI)[1,1]
   scalar ul31 = r(CI)[1,2]

	boottest treat_x_1813 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
	
    scalar ll41 = r(CI)[1,1]
   scalar ul41 = r(CI)[1,2]

	boottest treat_x_1815 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
	
    scalar ll51 = r(CI)[1,1]
   scalar ul51 = r(CI)[1,2]

	boottest treat_x_1816 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
	
     scalar ll61 = r(CI)[1,1]
   scalar ul61 = r(CI)[1,2]

	boottest treat_x_1817 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
	
	  scalar ll71 = r(CI)[1,1]
   scalar ul71 = r(CI)[1,2]

	boottest treat_x_1818 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
	
 scalar ll81 = r(CI)[1,1]
   scalar ul81 = r(CI)[1,2]

	boottest treat_x_1819 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)
	
 scalar ll91 = r(CI)[1,1]
   scalar ul91 = r(CI)[1,2]

	boottest treat_x_1820 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
	
   scalar ll101 = r(CI)[1,1]
   scalar ul101 = r(CI)[1,2]

	boottest treat_x_1821 , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
	
   scalar ll111 = r(CI)[1,1]
   scalar ul111 = r(CI)[1,2]


	
	
	* save residual degrees of freedom 
	local df = e(df_r)

	*** save regression into external file for graphing
		
	tempname p /* prepare external file */
	tempfile figures
	* save coefficients, standard errors, # obs & degrees of freedom
	postfile `p' float beta sebeta N df year using `figures', replace

	foreach y of numlist 1810(1)1813 1815(1)1821 { /* save regression estimates in external file*/
		post `p'  (_b[treat_x_`y']) (_se[treat_x_`y']) (`e(N)') (`e(df_r)') (`y')
	}

	
	
	postclose `p'
 	
	preserve
	
	gen before=0
		replace before=1 if year<1814
	
	gen treat_before = 0
		replace treat_before= before * prussia1815
		
	gen treat_after = 0
		replace treat_after= after * prussia1815
		
	
	
	*** pre/post regression (simple diff in diff with one post-period and one pre-period)
	
	
	areg `dependent_variable' ///
		treat_before treat_after ///
		year1810-year1813 ///
		year1815-year1821 ///
		, ///
		cluster(place_id) absorb(place)

	boottest treat_before , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
   scalar lldummy11 = r(CI)[1,1]
   scalar uldummy11 = r(CI)[1,2]

	boottest treat_after , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)	
	
   scalar lldummy21 = r(CI)[1,1]
   scalar uldummy21 = r(CI)[1,2]
	
	
	
	* save residual degrees of freedom 
	local dfdd = e(df_r)
	
	* save coefficients and standard errors
	local betapre  = _b[treat_before]
	local sepre    = _se[treat_before]
	local betapost = _b[treat_after]
	local sepost   = _se[treat_after]
	


	*** prepare graph
	
	clear /* use external file for graphing */
	use `figures'
	
	* generate a data point for 1814? 
	expand 2 if year==1813, gen(mark_expanded) 
	replace year=1814 if year==1813 & mark_expanded==1
	drop mark_expanded
	replace beta=0 if year==1814
	replace se=0 if year==1814

	
    * drop if exists for upper & lower bound of confidence intervals (decade level)
	cap drop ub_beta
	cap drop lb_beta   
	
	* generate upper & lower bound for confidence intervals (decade level)
	matrix ub_beta_m = (ul11 \ ul21\ ul31\ ul41\ ul51\ ul61\ ul71\ ul81\ ul91\ ul101\ ul111)
    matrix lb_beta_m = (ll11\ ll21\ ll31\ ll41\ ll51\ ll61\ ll71\ ll81\ ll91\ ll101\ ll111)
	gen ub_beta =  ub_beta_m[1,1] if year != 1814
	gen lb_beta = lb_beta_m[1,1] if year != 1814
foreach i of numlist 2(1)11 {
    replace ub_beta = ub_beta_m[`i', 1] if _n == `i'
    replace lb_beta = lb_beta_m[`i', 1] if _n == `i'
}
	
	* line for pre-coefficient (from simpe diff in diff regression)
	gen betapre = `betapre' if year<=1813   

* generate upper & lower bound for confidence intervals (decade level)
   matrix ub_beta_pre_m = (uldummy11)
   matrix lb_beta_pre_m = (lldummy11)
   gen ub_betapre =  ub_beta_pre_m[1,1] if year<=1813 
   gen lb_betapre = lb_beta_pre_m[1,1] if year<=1813 
	*gen ub_beta = beta+invttail(`df',0.025)*se  
	*gen lb_beta = beta+invttail(`df',0.975)*se  
	
	
	* generate upper & lower bound for confidence intervals (pre coefficient)
	*gen ub_betapre = betapre+invttail(`dfdd',0.025)*`sepre'
	*gen lb_betapre = betapre+invttail(`dfdd',0.975)*`sepre'
	
	

	* line for post-coefficient (from simpe diff in diff regression)
	gen betapost = `betapost' if year>=1815 & year<=1821
	
	* generate upper & lower bound for confidence intervals (post coefficient)
	*gen ub_betapost = betapost+invttail(`dfdd',0.025)*`sepost'
	*gen lb_betapost = betapost+invttail(`dfdd',0.975)*`sepost'
   
   matrix ub_beta_post_m = (uldummy21)
   matrix lb_beta_post_m = (lldummy21)
   gen ub_betapost =  ub_beta_post_m[1,1] if year>=1815 & year<=1821
   gen lb_betapost = lb_beta_post_m[1,1] if year>=1815 & year<=1821

	
	* place observations at center of decade 
    *gen yearshift = year+5
	sort year

	* to do: Replace betapre with this but with correctconfidence intervals of pre and post
* graph 
	twoway ///
		(rarea ub_betapre lb_betapre year, color(`color') fintensity(0) lwidth(vthin)) ///
		(line betapre year, lcolor(`color') lwidth(medthick) ) ///
		(rarea ub_betapost lb_betapost year, color(`color') fintensity(7) lwidth(vthin)) ///
		(line betapost year, lcolor(`color') lwidth(medthick) ) ///
		(rspike ub_beta lb_beta year, lcolor(`color') lwidth(thick) ) ///
		(scatter beta year, msymbol(Oh) mcolor(`color') msize(vlarge)) ///
		(function y = 0, lcolor(black) range(year)) ///
		, ///
		title(`graphtitle') ///
		ytitle("Point estimate / C.I.", size(large)) xtitle("") ///
		yline(0, lcolor(black)) ///
		xline(1814, lcolor(black)) ///
		xscale(range(1810 1821)) xlabel(1810(1)1821, labsize(large)) ///
		ylabel(, labsize(large)) ///
		scheme(s1color) legend(off) ///
		name(`graphname', replace)	

	window manage close graph
	
	restore 

end


	* generate upper & lower bound for confidence intervals (pre coefficient)
*matrix ub_betapre_m = (ul11, ul21, ul31, ul41)
*matrix lb_betapre_m = (ll11, ll21, ll31, ll41)

* Convert matrices to variables
*gen ub_betapre = ub_betapre_m[1,1] if year<=1813   
*gen lb_betapre = lb_betapre_m[1,1] if year<=1813   

	* line for post-coefficient (from simpe diff in diff regression)
*	gen betapost = `betapost' if year>=1815 & year<=1821
	
	* generate upper & lower bound for confidence intervals (post coefficient)
	
	
*	gen ub_betapost = ub_betapost_m[1,1] if year>=1815 & year<=1821
*	gen lb_betapost = lb_betapost_m[1,1] if year>=1815 & year<=1821

