

use "$data/data_tab2", replace
	
groups childfirst if treat==1 & year<1815, sel(15) order(h)
groups childfirst if treat==1 & year>1814, sel(15) order(h)
		
groups childfirst if treat==0 & year<1815, sel(15) order(h)
groups childfirst if treat==0 & year>1814, sel(15) order(h)
