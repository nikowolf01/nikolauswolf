use "data_tab5", clear
	
	
tab place if family_id=="0"	
foreach place in Aachen Muenster Frankfurt Hannover Heidelberg Mannheim Nuernberg Berlin {
estpost tabstat child_nat if place=="`place'" & family_id=="0", by(after) statistics(mean) listwise
}

tab place if family_id!="0" & match==1

foreach place in Aachen  Muenster Frankfurt Hannover Heidelberg Mannheim Nuernberg Berlin {
estpost tabstat child_nat if place=="`place'" & family_id!="0" & match==1, by(after) statistics(mean) listwise
}
