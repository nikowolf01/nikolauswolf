use "$data/data_fig3", clear

foreach year in 1810 1811 1812 1813 1814 1815 1816 1817 1818 1819 1820 1821 {
gen year`year' = 0
	replace year`year'=1 if year==`year'
} 

foreach year in 1810 1811 1812 1813 1814 1815 1816 1817 1818 1819 1820 1821 {
gen treat_x_`year' = 0
	replace treat_x_`year'=year`year' * prussia1815 
}
	
do "$code/figure 3 help.do" 

reg_figure3		child_nat_first, color("black") graphtitle("National first name (dummy)") ///
				graphname("national_city")
				
graph combine national_city, ysize(3) scheme(s1color)
graph export "$output/Figure 3.pdf", replace

				
