
use "$data/data_tab4_b", clear

sum nat 	
sum nat_fw  	
sum nat_1815

bys order: sum nat

sum nat 		if nat_korp==0
sum nat_fw  	if nat_korp==0
sum nat_1815	if nat_korp==0

use "$data/data_tab4_a", clear

sum nat 		
sum nat_fw  	
sum nat_1815 	
ttest 		nat=0.4217 			
ttest 		nat_fw=0.1448 		
ttest 		nat_1815=0.2079 	

bys order: sum nat
ttest 		nat=0.4249 		if order==1 
ttest 		nat=0.4563 		if order==2 
ttest 		nat=0.2534 		if order==3 

sum nat 		if  nat_korp==0
sum nat_fw  	if  nat_korp==0
sum nat_1815 	if 	nat_korp==0

ttest 		nat=0.4171 			if nat_korp==0
ttest 		nat_fw=0.1471 		if nat_korp==0
ttest 		nat_1815=0.2034 	if nat_korp==0


