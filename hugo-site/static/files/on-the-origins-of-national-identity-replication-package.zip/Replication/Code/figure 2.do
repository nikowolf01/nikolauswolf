use "$data/data_fig2_a", clear

graph bar child_nat_first  child_rel_first child_lat_first child_eu_first   child_other_first child_not_first if treat==1, over(year) stack legend(position(6) rows(2) label (1 "National") label (2 "Religious") label (3 "Latin") label (4 "European") label (5 "Other") label (6 "Not")) bar(1, lp (solid)) bar(2, lp(longdash)) bar(3, lp(dash)) bar(4, lp(dot)) bar(5, lp(dash dot)) bar(6, lp(shortdash))

graph export "$output/Figure 2a.pdf", replace

graph bar child_nat_first  child_rel_first child_lat_first child_eu_first   child_other_first child_not_first if treat==0, over(year) stack legend(position(6) rows(2) label (1 "National") label (2 "Religious") label (3 "Latin") label (4 "European") label (5 "Other") label (6 "Not"))  bar(1, lp (solid)) bar(2, lp(longdash)) bar(3, lp(dash)) bar(4, lp(dot)) bar(5, lp(dash dot)) bar(6, lp(shortdash))

graph export "$output/Figure 2b.pdf", replace

*

use "$data/data_fig2_b", clear

graph bar child_nat  child_rel child_lat child_eu   child_other child_not if treat==1, over(year) stack legend(position(6) rows(2) label (1 "National") label (2 "Religious") label (3 "Latin") label (4 "European") label (5 "Other") label (6 "Not")) bar(1, lp (solid)) bar(2, lp(longdash)) bar(3, lp(dash)) bar(4, lp(dot)) bar(5, lp(dash dot)) bar(6, lp(shortdash))
graph export "$output/Figure 2c.pdf", replace

graph bar child_nat  child_rel child_lat child_eu   child_other child_not if treat==0, over(year) stack legend(position(6) rows(2) label (1 "National") label (2 "Religious") label (3 "Latin") label (4 "European") label (5 "Other") label (6 "Not")) bar(1, lp (solid)) bar(2, lp(longdash)) bar(3, lp(dash)) bar(4, lp(dot)) bar(5, lp(dash dot)) bar(6, lp(shortdash))
graph export "$output/Figure 2d.pdf", replace
