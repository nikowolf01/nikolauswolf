
*Column 1

use "$dta/data_tab6_a", clear

eststo tab1_1: areg 	child_nat_first	prussia1815_treat		after , cluster(place_id) absorb(place_id)
	estadd local placefe 		"\checkmark"
local vars = ustrregexra("`:colnames e(b)'", "o\.\w+|\d+b\.\w+|\_cons|after", "")
local pvals
set seed 02202022
foreach var of local vars{
    boottest prussia1815_treat , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb) 
    local pvals= "`pvals' `=r(p)'"
}
di "`pvals'"

foreach stat in pvals{
    local `stat'= "("+ ustrregexra(trim("``stat''"), " ", ",") + ")"
    mat `stat'= ``stat''
    mat colnames `stat'= `vars'
    estadd matrix `stat': tab1_1
}

*Column 2

use "$dta/data_tab6_b", clear

eststo tab1_2: xtreg 	child_nat_first	prussia1815_treat		after  , fe cluster(place_id)
	estadd local familyfe 		"\checkmark"
local vars = ustrregexra("`:colnames e(b)'", "o\.\w+|\d+b\.\w+|\_cons|after", "")
local pvals
set seed 02202022
foreach var of local vars{
    boottest prussia1815_treat , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)
    local pvals= "`pvals' `=r(p)'"
}
di "`pvals'"

foreach stat in pvals{
    local `stat'= "("+ ustrregexra(trim("``stat''"), " ", ",") + ")"
    mat `stat'= ``stat''
    mat colnames `stat'= `vars'
    estadd matrix `stat': tab1_2
}


*Column 3

use "$dta/data_tab6_c", replace

eststo tab1_3: 	areg	child_nat_first	prussia1815_treat 		after , cluster(place_id) absorb(place_id)
	estadd local placefe 		"\checkmark"
local vars = ustrregexra("`:colnames e(b)'", "o\.\w+|\d+b\.\w+|\_cons|after", "")
local pvals
set seed 02202022
foreach var of local vars{
    boottest prussia1815_treat , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)
    local pvals= "`pvals' `=r(p)'"
}
di "`pvals'"

foreach stat in pvals{
    local `stat'= "("+ ustrregexra(trim("``stat''"), " ", ",") + ")"
    mat `stat'= ``stat''
    mat colnames `stat'= `vars'
    estadd matrix `stat': tab1_3
}

*Column 4


use "$dta/data_tab6_d", replace

eststo tab1_4: 	xtreg	child_nat_first 	prussia1815_treat 	after , fe cluster(place_id)
	estadd local familyfe 		"\checkmark"
local vars = ustrregexra("`:colnames e(b)'", "o\.\w+|\d+b\.\w+|\_cons|after", "")
local pvals
set seed 02202022
foreach var of local vars{
    boottest prussia1815_treat , cluster(place_id) rep(1000) seed(12345) nograph boottype(wild) bootcluster(place_id) weight(webb)
    local pvals= "`pvals' `=r(p)'"
}
di "`pvals'"

foreach stat in pvals{
    local `stat'= "("+ ustrregexra(trim("``stat''"), " ", ",") + ")"
    mat `stat'= ``stat''
    mat colnames `stat'= `vars'
    estadd matrix `stat': tab1_4
}


local titles " Dep. var. & \multicolumn{4}{c}{National first name (dummy)} \\ & \multicolumn{2}{c}{excluding ruler first names}  & \multicolumn{2}{c}{including ruler first names}  \\" 
	
#delimit ;
estout tab1_1 tab1_2 tab1_3 tab1_4 	using "$output/Table 6.tex",									
	replace
	starlevels			(* 0.10 ** 0.05 *** 0.01)
	varlab			(	prussia1815_treat 	"Treated $\times$ Post1815")
	keep (prussia1815_treat)
	collabels(none) 
	style(tex) cells(b(fmt(3) pvalue(pvals) star) pvals(fmt(3) par))
	stats(placefe familyfe N N_g, fmt(%~3s %~3s %9.0f %9.0f) 
	labels	("City FE" "Family FE" "Observations" "Families"))
	mlabels("" "" "" "", span prefix(\multicolumn{@span}{c}{) suffix(}) numbers)
	prehead("\begin{tabularx}{1\textwidth}{Xcccc}" "\toprule  `titles' ")
	posthead("\midrule") prefoot("\midrule") postfoot("\bottomrule" "\end{tabularx}");
	#delimit cr
	*/	
	
