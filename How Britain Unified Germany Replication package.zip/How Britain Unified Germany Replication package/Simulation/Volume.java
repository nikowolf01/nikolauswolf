package vienna2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Volume
{

	public enum Reason {
		DETOURED, CHOKED, BERTRAND, NONE
	}

	private int destination_id;
	private String destination_name;
	private double revenue = 0;
	private double price = 0;
	private double demand = 0;
	private double pcdemand = 0;
	private double tariff;
	private double other_tariffs;
	private String reason;
	private String reason_expl;
	private boolean transit;
	

	public String getReason_expl()
	{
		return reason_expl;
	}

	public void setReason_expl(String reason_expl)
	{
		this.reason_expl = reason_expl;
	}

	public int getDestination_id()
	{
		return destination_id;
	}

	public void setDestination_id(int destination_id)
	{
		this.destination_id = destination_id;
	}

	public String getDestination_name()
	{
		return destination_name;
	}

	public void setDestination_name(String destination_name)
	{
		this.destination_name = destination_name;
	}

	public double getRevenue()
	{
		return revenue;
	}

	public void setRevenue(double revenue)
	{
		this.revenue = revenue;
	}

	public double getPrice()
	{
		return price;
	}

	public void setPrice(double price)
	{
		this.price = price;
	}

	public double getDemand()
	{
		return demand;
	}

	public void setDemand(double demand)
	{
		this.demand = demand;
	}

	public void writeOut(int period, State state, Connection con, ViennaSimulator v)
	{
		try
		{
			PreparedStatement stmt = con.prepareStatement("INSERT INTO " + v.tariff_table
					+ "(period, state, tariff, revenue, demand,pcdemand, price, destination,reason,reason_expl,transit,othertariffs) VALUES (?, ?, ?, ?, ?, ?, ?,?,?,?,?,?)");
			stmt.setInt(1, period);
			stmt.setInt(2, state.getStaat_id());
			stmt.setDouble(3, this.getTariff());
			stmt.setDouble(4, this.getRevenue());
			stmt.setDouble(5, this.getDemand());
			stmt.setDouble(6, this.getPcdemand());
			stmt.setDouble(7, this.getPrice());
			stmt.setInt(8, this.getDestination_id());
			stmt.setString(9, this.getReason());
			stmt.setString(10, this.getReason_expl());
			stmt.setBoolean(11, isTransit());
			stmt.setDouble(12, this.getOther_tariffs());
			stmt.execute();
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public double getTariff()
	{
		return tariff;
	}

	public void setTariff(double tariff)
	{
		this.tariff = tariff;
	}

	public double getPcdemand()
	{
		return pcdemand;
	}

	public void setPcdemand(double pcdemand)
	{
		this.pcdemand = pcdemand;
	}

	public String getReason()
	{
		return reason;
	}

	public void setReason(String reason)
	{
		this.reason = reason;
	}

	public boolean isTransit()
	{
		return transit;
	}

	public void setTransit(boolean transit)
	{
		this.transit = transit;
	}

	public double getOther_tariffs()
	{
		return other_tariffs;
	}

	public void setOther_tariffs(double other_tariffs)
	{
		this.other_tariffs = other_tariffs;
	}
}
