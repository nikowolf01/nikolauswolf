package vienna2;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class State
{
	private String staat_name;
	private int staat_id;

	public State(int staat_id)
	{
		this.staat_id=staat_id;
	}

	public String getStaat_name()
	{
		return staat_name;
	}

	public void setStaat_name(String staat_name)
	{
		this.staat_name = staat_name;
	}

	public int getStaat_id()
	{
		return staat_id;
	}

	public void setStaat_id(int staat_id)
	{
		this.staat_id = staat_id;
	}

	public ArrayList<Destination> getTransits(Connection con, ViennaSimulator viennaSimulator)
	{
		ArrayList<Destination> destinations=new ArrayList<Destination>();
		try
		{
			PreparedStatement stmt = con.prepareStatement(
					"WITH transit_query AS( "
					+ "SELECT * FROM (SELECT end_vid,"
					+ "(SELECT pop FROM "+viennaSimulator.states_table+" WHERE ways_node=end_vid) AS pop,"
					+ "(SELECT reg_name FROM "+viennaSimulator.states_table+" WHERE ways_node=end_vid) AS reg_name,"
					+ "(SELECT staat_id FROM "+viennaSimulator.states_table+" WHERE ways_node=end_vid) AS staat_id,"
					+ "(SELECT income FROM "+viennaSimulator.states_table+" WHERE ways_node=end_vid) AS income,"
					+" sum("+viennaSimulator.ways_table+".cost) AS physical_cost,"
					+ "uniq(sort(array_agg_mult(crosses))) AS crosses,"
					+ "(SELECT SUM(tariff) FROM "+viennaSimulator.optimal_table+" WHERE (state,period) IN (SELECT state,MAX(period) FROM "+viennaSimulator.optimal_table+" GROUP BY state) AND NOT state="+this.getStaat_id()+" AND state=ANY(uniq(sort(array_agg_mult(crosses))))) AS other_tariffs"
					+ " FROM "+viennaSimulator.ways_table+" JOIN LATERAL "
					+ "pgr_dijkstra('SELECT gid AS id, source, target, cost FROM "+viennaSimulator.ways_table+"', "
					+ "(SELECT ways_node FROM "+viennaSimulator.states_table+" WHERE hauptstadt='London'),"
					+ "(SELECT array_agg(ways_node) FROM "+viennaSimulator.states_table+" WHERE hauptstadt!='London'),FALSE) sub"
					+ " ON sub.edge="+viennaSimulator.ways_table+".gid GROUP BY end_vid) sub WHERE ARRAY["+this.getStaat_id()+"]<@crosses)"
					+ ",detour_query AS("
					+ "SELECT * FROM (SELECT end_vid,"
					+ "sum("+viennaSimulator.ways_table+".cost) AS detour_physical,"
					+ "(uniq(sort(array_agg_mult(crosses)))) AS detour_crosses,"
					+ "(SELECT SUM(tariff) FROM "+viennaSimulator.optimal_table+" WHERE (state,period) IN (SELECT state,MAX(period) FROM "+viennaSimulator.optimal_table+" GROUP BY state) AND NOT state="+this.getStaat_id()+" AND state=ANY(uniq(sort(array_agg_mult(crosses))))) AS detour_tariffs "
					+ "FROM "+viennaSimulator.ways_table+" JOIN LATERAL "
					+ "pgr_dijkstra('SELECT gid AS id, source, target, cost FROM "+viennaSimulator.ways_table+" WHERE NOT ARRAY["+this.getStaat_id()+"]<@crosses',"
					+ "(SELECT ways_node FROM "+viennaSimulator.states_table+" WHERE hauptstadt='London'),"
					+ " (SELECT array_agg(end_vid) FROM transit_query),FALSE) sub ON sub.edge="+viennaSimulator.ways_table+".gid GROUP BY end_vid) sub)"
					+ "SELECT transit_query.end_vid,transit_query.reg_name,transit_query.staat_id,pop,income,physical_cost,crosses,other_tariffs,detour_physical,detour_crosses,detour_tariffs"
					+ " FROM transit_query LEFT JOIN detour_query ON transit_query.end_vid=detour_query.end_vid");
			System.out.println(stmt);
			stmt.execute();
			ResultSet result=stmt.getResultSet();
			while(result.next())
			{
				Destination d=new Destination();
				d.setId(result.getInt("end_vid"));
				d.setPop(result.getDouble("pop"));
				d.setReg_name(result.getString("reg_name"));
				d.setStaat_id(result.getInt("staat_id"));
				d.setDirect_physical(viennaSimulator.SOMBART_EX*result.getDouble("physical_cost")/1000); //Transport price per kilogram in g silver
				if(result.getArray("crosses")!=null)
				{
					Integer[] stateids=(Integer[])result.getArray("crosses").getArray();
					for(Integer stateid:stateids)
					{
						d.getDirect_crosses().add(new State(stateid.intValue()));
					}
				}
				d.setDirect_otherTariffs(result.getDouble("other_tariffs"));
				d.setDetour_physical(viennaSimulator.SOMBART_EX*result.getDouble("detour_physical")/1000); //Transport price per kilogram in g silver
				if(result.wasNull())
				{
					d.setDetour_exists(false);
				}else {
					d.setDetour_exists(true);
				}
				if(result.getArray("detour_crosses")!=null)
				{
					Integer[] stateids=(Integer[])result.getArray("detour_crosses").getArray();
					for(Integer stateid:stateids)
					{
						d.getDetour_crosses().add(new State(stateid.intValue()));
					}
				}
				d.setDetour_tariffs(result.getDouble("detour_tariffs"));
				destinations.add(d);
			}
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return destinations;
	}
}
