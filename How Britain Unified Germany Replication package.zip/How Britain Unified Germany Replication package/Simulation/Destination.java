package vienna2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Destination
{
	private int id;
	private double pop;
	private String reg_name;
	private int staat_id;
	private double direct_physical;
	private ArrayList<State> direct_crosses = new ArrayList<State>();
	private double direct_otherTariffs;
	private boolean detour_exists;
	private double detour_physical;
	private ArrayList<State> detour_crosses = new ArrayList<State>();
	private double detour_tariffs;

	public class BertrandResponse
	{
		private State state;
		private double loss;
		private double newTariff;
		public State getState()
		{
			return state;
		}
		public void setState(State state)
		{
			this.state = state;
		}
		public double getLoss()
		{
			return loss;
		}
		public void setLoss(double loss)
		{
			this.loss = loss;
		}
		public double getGain()
		{
			return gain;
		}
		public void setGain(double gain)
		{
			this.gain = gain;
		}
		public double getDetour()
		{
			return detour;
		}
		public void setDetour(double detour)
		{
			this.detour = detour;
		}
		public double getNewTariff()
		{
			return newTariff;
		}
		public void setNewTariff(double newTariff)
		{
			this.newTariff = newTariff;
		}
		private double gain;
		private double detour;
	}

	public double getPop()
	{
		return pop;
	}

	public void setPop(double pop)
	{
		this.pop = pop;
	}

	public String getReg_name()
	{
		return reg_name;
	}

	public void setReg_name(String reg_name)
	{
		this.reg_name = reg_name;
	}

	public double getDirect_physical()
	{
		return direct_physical;
	}

	public void setDirect_physical(double direct_physical)
	{
		this.direct_physical = direct_physical;
	}

	public ArrayList<State> getDirect_crosses()
	{
		return direct_crosses;
	}

	public void setDirect_crosses(ArrayList<State> direct_crosses)
	{
		this.direct_crosses = direct_crosses;
	}

	public double getDirect_otherTariffs()
	{
		return direct_otherTariffs;
	}

	public void setDirect_otherTariffs(double direct_otherTariffs)
	{
		this.direct_otherTariffs = direct_otherTariffs;
	}

	public double getDetour_physical()
	{
		return detour_physical;
	}

	public void setDetour_physical(double detour_physical)
	{
		this.detour_physical = detour_physical;
	}

	public ArrayList<State> getDetour_crosses()
	{
		return detour_crosses;
	}

	public void setDetour_crosses(ArrayList<State> detour_crosses)
	{
		this.detour_crosses = detour_crosses;
	}

	public double getDetour_tariffs()
	{
		return detour_tariffs;
	}

	public void setDetour_tariffs(double detour_tariffs)
	{
		this.detour_tariffs = detour_tariffs;
	}

	public boolean isDetour_exists()
	{
		return detour_exists;
	}

	public void setDetour_exists(boolean detour_exists)
	{
		this.detour_exists = detour_exists;
	}

	public BertrandResponse bertrandResponse(double tariff, Connection con, ViennaSimulator v)
	{
		for (State competitor : this.getDetour_crosses())
		{
			for(State directState: this.getDirect_crosses())
			{
				if(competitor.getStaat_id()==directState.getStaat_id())
				{
					break;
				}
			}
			try
			{
				double bertrand_loss = 0;
				double bertrand_gain = 0;
				PreparedStatement stmt = con.prepareStatement("SELECT tariff, revenue FROM " + v.optimal_table + " "
						+ "WHERE  (state,period) IN (SELECT state, MAX(period) FROM " + v.tariff_table
						+ " GROUP BY state) AND state=" + competitor.getStaat_id());
				stmt.execute();
				ResultSet result = stmt.getResultSet();
				while (result.next())
				{
					if (result.getDouble("revenue") != 0 || !result.wasNull())
					{
						double old_tariff = result.getDouble("tariff");
						double reduction = this.direct_physical + this.direct_otherTariffs + tariff
								- this.detour_physical - this.detour_tariffs;
						if (old_tariff + reduction < 0)
							break;
						double destination_price = v.london_price + this.getDetour_physical() + this.getDetour_tariffs()
								+ reduction;
						double pc_demand=v.C*Math.pow(destination_price,v.elasticity);
						bertrand_gain += (old_tariff + reduction)
								* (this.getPop() * pc_demand);
						PreparedStatement stmt2 = con.prepareStatement(
								"SELECT a.elem AS destination, destinations_demand[a.nr] as destinations_demand,"
										+ "destinations_price[a.nr] AS destinations_price,(SELECT income FROM "
										+ v.states_table
										+ " WHERE ways_node=a.elem) AS destinations_income,(SELECT pop FROM "
										+ v.states_table + " WHERE ways_node=a.elem) AS destinations_pop FROM "
										+ v.optimal_table + ","
										+ "unnest(destinations) WITH ORDINALITY a(elem, nr) WHERE state="
										+ competitor.getStaat_id()
										+ " AND (state,period) IN (SELECT state, MAX(period) FROM " + v.optimal_table
										+ "  GROUP BY state);");
						ResultSet result2 = stmt2.executeQuery();
						while (result2.next())
						{
							double old_demand = result2.getDouble("destinations_pop")*(v.C*Math.pow(result2.getDouble("destinations_price"),v.elasticity));
							double new_demand = result2.getDouble("destinations_pop")*(v.C*Math.pow(result2.getDouble("destinations_price")+reduction,v.elasticity));
							bertrand_loss += ((old_tariff + reduction) * new_demand) - (old_tariff * old_demand);
						}
					}
				}
				if (bertrand_gain + bertrand_loss > 0)
				{
					BertrandResponse r=new BertrandResponse();
					r.setDetour(this.getDirect_physical()-this.getDetour_physical());
					r.setGain(bertrand_gain);
					r.setLoss(bertrand_loss);
					r.setState(competitor);
					r.setNewTariff(tariff);
					return r;
				}
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getStaat_id()
	{
		return staat_id;
	}

	public void setStaat_id(int staat_id)
	{
		this.staat_id = staat_id;
	}
}
