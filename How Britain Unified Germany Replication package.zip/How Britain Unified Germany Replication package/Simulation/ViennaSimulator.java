package vienna2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import vienna2.Destination.BertrandResponse;

//The prerequisite for this program is that you have a states table and a waystable. A template for the waystable is provided in create_waystable.sql
//If you are overwriting a lot of tables, you may use cleanUp(theCase); NEVER DO THIS UNLESS YOU ARE ABSOLUTELY SURE!

public class ViennaSimulator implements Runnable {
	String states_table;
	String ways_table = "ways";
	String tariff_table; // = "jehA_tariff_random_";
	String demand_table; // = "jehA_demand_random_";
	String optimal_table; // = "jehA_optimal_random_";
	String shortest_table;
	Boolean SHUFFLE = true;
	Boolean AGGREGATE_BEFORE_ORDER = false;
	Boolean PRUSSIA_FIRST = false;
	String ORDER = "RANDOM()";

	static Boolean calibrate = false;	
	public static double CALIBRATED_LONDON_PRICE=9.36;
	public static double CALIBRRATED_CHOKE_QUANTITY=2.75;
	public static double CALIBRATED_C=672.494;
	public static double CALIBRATED_ELASTICITY = -2.34;
	
	public double london_price=9.76;
	public double choke_quantity=2.75;
	public double C=763.406;
	public double elasticity=-0.3;

	public static double MIN_TARIFF = 0.001;

	double SOMBART_EX = 5.556; // Sombart's estimates in Mark, which is 5.556 g silver

	private static double MAX_TARIFF_STEP = 1;
	public static double MAX_START_TARIFF = MAX_TARIFF_STEP;
	private static int ROUNDS = 50;

	private Connection con;
	private ArrayList<State> states;
	
	//This is an example main. You can	
	public static void main(String[] args) throws SQLException {

		ExecutorService pool = Executors.newFixedThreadPool(10);

		List<String> cases = new ArrayList<String>();
		cases.add("0");
		cases.add("little");
		cases.add("little_south");
		cases.add("little_hdasouth");
		cases.add("littlehda_south");
		cases.add("1");
		cases.add("2");
		cases.add("3");
		cases.add("4");
		cases.add("5");
		cases.add("cf1");
		cases.add("cf2");
		cases.add("cf3");
		cases.add("cf4");

		if (ViennaSimulator.calibrate) {
			String theCase = "little";
			for (int n = 1; n < 10; n++) {
				double choke = 2 + (.1 * n);
				System.out.println(choke);
				String chokeString = Double.toString(choke).replace(".", "");
				for (int i = 1; i <= 10; i++) {
					ViennaSimulator vs = new ViennaSimulator(theCase, String.valueOf(i), choke, chokeString);
					Thread t1 = new Thread(vs);
					pool.execute(t1);
				}

			}
		} else {

			for (String theCase : cases) {
				for (int i = 1; i <= 30; i++) {
					ViennaSimulator vs = new ViennaSimulator(theCase, String.valueOf(i));
					Thread t1 = new Thread(vs);
					pool.execute(t1);
					
				}
			}
			pool.shutdown();
		}
	}

	public ViennaSimulator(String theCase, String run) {
		this.states_table = "network_states_" + theCase;
		this.ways_table = "ways_" + theCase;
		this.tariff_table = "case_" + theCase + "_tariff_random_" + run;
		this.demand_table = "case_" + theCase + "_demand_random_" + run;
		this.optimal_table = "case_" + theCase + "_optimal_random_" + run;
		this.shortest_table = "shortest_" + theCase + "_random";
	}
	
	public ViennaSimulator(String theCase, String run, String manipulation) {
		this.states_table = "network_states_" + theCase + "_" + manipulation;
		this.ways_table = "ways_" + theCase + "_" + manipulation;
		this.tariff_table = "case_" + theCase + "_"+ manipulation +  "_tariff_random_" + run;
		this.demand_table = "case_" + theCase + "_"+ manipulation + "_demand_random_" + run;
		this.optimal_table = "case_" + theCase + "_"+ manipulation + "_optimal_random_" + run;
		this.shortest_table = "shortest_" + theCase + "_"+ manipulation + "_random";
	}

	public ViennaSimulator(String theCase, String run, double chokeQuantity, String tableAppendix) {
		this.states_table = "network_states_" + theCase;
		this.ways_table = "ways_" + theCase;
		this.tariff_table = "case_" + tableAppendix + theCase + "_tariff_random_" + run;
		this.demand_table = "case_" + tableAppendix + theCase + "_demand_random_" + run;
		this.optimal_table = "case_" + tableAppendix + theCase + "_optimal_random_" + run;
		this.shortest_table = "shortest_" + tableAppendix + theCase + "_random";
		this.choke_quantity = chokeQuantity;
		System.out.println("Tariff-table:" + tariff_table);
	}
	
	public ViennaSimulator(String theCase, String tableAppendix,double london_price, double C, double elasticity, double choke_quantity, String run)
	{
		this.states_table = "network_states_" + tableAppendix;
		this.ways_table = "ways_" + tableAppendix;
		this.london_price=london_price;
		this.C=C;
		this.elasticity=elasticity;
		this.choke_quantity=choke_quantity;
		this.tariff_table=theCase+"_tariff_random_"+run;
		this.demand_table=theCase+"_demand_random_"+run;
		this.optimal_table=theCase+"_optimal_random_"+run;
	}

	public void run() {
		this.con = connect();
		if (con != null) {
			this.empty();
			// this.shortest();
			this.summary();
			this.initTariffs();

			for (

					int round = 1; round <= ROUNDS; round++) {
				this.runRound(round);
			}

		} else {
			System.out.println("Is done. Nothing to do.");
		}
		disconnect(con);
	}

	private void summary() {
		System.err.println("---------------------------------------------------");
		System.err.println("Here is your calibration:");
		System.err.println("Your basket's London price in grams of silver is " + london_price);
		System.err.println("Your basket's C is " + C);
		try {
			PreparedStatement stmt = con.prepareStatement("SELECT avg(income) FROM " + states_table);
			ResultSet result = stmt.executeQuery();
			/*
			 * result.next(); stmt = con.prepareStatement(
			 * "SELECT avg(cost) FROM (SELECT SUM(cost) AS cost FROM "
			 * +shortest_table+" GROUP BY end_vid) sub"); result = stmt.executeQuery();
			 * result.next(); System.err.
			 * println("The average physical costs from London in grams of silver in sample is "
			 * + SOMBART_EX * (result.getDouble(1) / 1000));
			 */
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.err.println(
				"I will now simulate by optimizing for all states in random order the tariff rate in maxium steps of "
						+ MAX_TARIFF_STEP + " grams of silver for " + ROUNDS + " round(s)");
		System.err.println("I assume that demand choked below " + this.choke_quantity + " kg / per capita");
		System.err.println("---------------------------------------------------");
	}

	private void shortest() {
		PreparedStatement stmt;
		try {
			stmt = con.prepareStatement("CREATE TABLE IF NOT EXISTS " + shortest_table + " AS SELECT sub.end_vid,seq,"
					+ ways_table + ".* FROM " + ways_table + " JOIN "
					+ "LATERAL pgr_dijkstra('SELECT gid AS id, source, target, cost FROM " + ways_table
					+ "', (SELECT ways_node FROM " + states_table + " WHERE hauptstadt='London'),"
					+ "(SELECT array_agg(ways_node) FROM " + states_table
					+ " WHERE hauptstadt!='London'),FALSE) sub ON sub.edge=" + ways_table + ".gid ORDER BY end_vid");
			System.out.println(stmt);
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void empty() {
		PreparedStatement stmt;
		try {
			stmt = con.prepareStatement("CREATE TABLE IF NOT EXISTS " + tariff_table + "("
					+ "    period integer NOT NULL," + "    state integer NOT NULL," + "    tariff double precision,"
					+ "    revenue double precision," + "    demand double precision," + "    destination integer,"
					+ "    reason character(1) COLLATE pg_catalog.\"default\","
					+ "    reason_expl character varying COLLATE pg_catalog.\"default\"," + "    transit boolean,"
					+ "    othertariffs double precision," + "    pcdemand double precision,"
					+ "    price double precision" + ")");
			stmt.execute();
			stmt = con.prepareStatement("DELETE FROM " + tariff_table);
			stmt.execute();
			stmt = con.prepareStatement("CREATE TABLE IF NOT EXISTS " + demand_table + "(" + "    state integer,"
					+ "    tariff double precision," + "    destination integer," + "    demand double precision,"
					+ "    price double precision," + "    revenue double precision," + "    period integer,"
					+ "    p integer" + ")");
			stmt.execute();
			stmt = con.prepareStatement("DELETE FROM " + demand_table);
			stmt.execute();
			stmt = con.prepareStatement("CREATE TABLE IF NOT EXISTS " + optimal_table + "("
					+ "    period integer NOT NULL," + "    state integer NOT NULL," + "    tariff double precision,"
					+ "    revenue double precision," + "    demand double precision," + "    destinations integer[],"
					+ "    destinations_demand double precision[]," + "    import double precision,"
					+ "    transit double precision," + "    destinations_price double precision[],"
					+ "    quota double precision" + ")");
			stmt.execute();
			stmt = con.prepareStatement("DELETE FROM " + optimal_table);
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void initTariffs() {
		try {
			PreparedStatement stmt = con.prepareStatement("INSERT INTO " + optimal_table
					+ "(period,state,tariff) SELECT 0,staat_id,(random()*" + MAX_START_TARIFF
					+ ") FROM (SELECT DISTINCT staat_name,staat_id FROM " + this.states_table + ") sub");
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void runRound(int period) {
		if (states == null) {
			states = this.loadStates();
		}
		if (SHUFFLE) {
			Collections.shuffle(states);
		}
		for (State state : states) {
			System.err.println(
					"Period " + period + ": Maximizing for " + state.getStaat_name() + "[" + state.getStaat_id() + "]");
			double old_tariff = 0;
			try {
				PreparedStatement myTariff = con.prepareStatement(
						"SELECT tariff FROM " + optimal_table + " WHERE state=? ORDER BY period DESC LIMIT 1");
				myTariff.setInt(1, state.getStaat_id());
				myTariff.execute();
				ResultSet result = myTariff.getResultSet();
				if (result.next()) {
					old_tariff = result.getDouble(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			double rand = Math.random() * MAX_TARIFF_STEP;
			for (Destination d : state.getTransits(con, this)) {
				Volume v = new Volume();
				v.setDestination_id(d.getId());
				v.setDestination_name(d.getReg_name());
				v.setTransit(state.getStaat_id() != d.getStaat_id());
				v.setOther_tariffs(d.getDirect_otherTariffs());
				// System.out.println("Regarding " + d.getReg_name() + " with costs p=" +
				// d.getDirect_physical()+", other tariffs="+d.getDirect_otherTariffs()
				// + " and detour costs " + (d.getDetour_physical() + d.getDetour_tariffs()
				// -d.getDirect_otherTariffs() - d.getDirect_physical()) + "(exists: "
				// + d.isDetour_exists() + "). Transit: " + v.isTransit());
				if (d.isDetour_exists() && !v.isTransit()) {
					System.err.println("There is a detour around import. Check your topology.");
				}
				int move = 0;
				double tariff = 0;
				while (move < 3) {
					if (move == 0) {
						tariff = old_tariff;
					} else {
						if (move == 1) {
							tariff = Math.max(old_tariff - rand, MIN_TARIFF);
						} else {
							tariff = old_tariff + rand;
						}
					}
					v.setTariff(tariff);
					if (d.isDetour_exists()) {
						if (d.getDirect_physical() + d.getDirect_otherTariffs() + tariff > d.getDetour_physical()
								+ d.getDetour_tariffs()) {
							// System.out.println("Reached detour at " + tariff);
							v.setDemand(0);
							v.setRevenue(0);
							v.setPrice(0);
							v.setReason("D");
						} else {
							if (tariff + d.getDirect_physical() > d.getDetour_physical()) {
								BertrandResponse competitor = d.bertrandResponse(tariff, con, this);
								if (competitor != null) {
									// System.out.println("Reached Bertrand response at " + tariff);
									v.setReason("B");
									v.setReason_expl("State " + competitor.getState().getStaat_id()
											+ " at detour costs " + competitor.getDetour() + " would reset tariff to "
											+ competitor.getNewTariff() + " gaining " + competitor.getGain()
											+ " while loosing " + competitor.getLoss());
									v.setDemand(0);
									v.setRevenue(0);
									v.setPrice(0);
								}
							}
						}
					}
					double destination_price = london_price + d.getDirect_physical() + d.getDirect_otherTariffs()
							+ tariff;
					v.setPrice(destination_price);
					double pc_demand = C * Math.pow(destination_price, elasticity);
					if (pc_demand > this.choke_quantity) {
						double revenue = tariff * pc_demand * d.getPop();
						v.setReason("N");
						v.setPcdemand(pc_demand);
						v.setDemand(pc_demand * d.getPop());
						v.setRevenue(revenue);
					} else {
						v.setReason("C");
						v.setPcdemand(0);
						v.setDemand(0);
						v.setRevenue(0);
						v.setReason_expl("Choked (choke quantity " + this.choke_quantity + ") demand at p.c. demand "
								+ pc_demand + " and " + destination_price);
					}
					v.writeOut(period, state, con, this);
					move++;
				}
			}
			try {
				PreparedStatement stmt = con.prepareStatement("INSERT INTO " + this.optimal_table
						+ "(period, state, tariff, revenue, demand, destinations,destinations_demand,destinations_price,transit,import,quota)"
						+ "SELECT " + period + "," + state.getStaat_id() + ","
						+ "CASE WHEN SUM(revenue)=0 THEN ? ELSE tariff END," + "SUM(revenue) AS revenue,"
						+ "SUM(demand) AS demand," + "array_agg(destination) AS destinations,"
						+ "array_agg(demand) AS demands," + "array_agg(price) AS prices,"
						+ "sum(transit::integer*revenue) AS transit," + "sum((1-transit::integer)*revenue) AS import,"
						+ "CASE WHEN sum(transit::integer*revenue)=0 THEN 0 ELSE sum(transit::integer*revenue)/SUM(revenue) END AS quota "
						+ "FROM " + this.tariff_table + " WHERE period=" + period + " AND state=" + state.getStaat_id()
						+ " GROUP BY tariff ORDER BY SUM(revenue) DESC LIMIT 1");
				stmt.setDouble(1, 0); // Back to zero
				// System.out.println(stmt);
				stmt.execute();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private static Connection connect() {
		Connection conn = null;
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection("jdbc:postgresql://krugman.wiwi.hu-berlin.de:5432/vienna2", "postgres",
					"Vienna1815");
			System.out.println("Opened database successfully");
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		return conn;
	}

	private static void disconnect(Connection conn) {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * Loads states in random order
	 */
	private ArrayList<State> loadStates() {
		ArrayList<State> states = new ArrayList<State>();
		try {
			PreparedStatement stmt;
			if (PRUSSIA_FIRST) {
				State state = new State(31);
				state.setStaat_name("Preu en");
				states.add(state);
			}
			if (!AGGREGATE_BEFORE_ORDER) {
				stmt = con.prepareStatement("SELECT staat_name,staat_id FROM (SELECT DISTINCT staat_name,staat_id FROM "
						+ states_table + " WHERE hauptstadt!='London') sub ORDER BY " + ORDER);
				stmt.execute();
			} else {
				stmt = con.prepareStatement(
						"SELECT staat_name,staat_id FROM (SELECT DISTINCT staat_name,staat_id,pop,reg_geom,st_area(reg_geom) AS area,large_rivers,oceans_dist FROM "
								+ states_table
								+ " WHERE hauptstadt!='London') sub GROUP BY staat_name,staat_id ORDER BY " + ORDER);
				stmt.execute();
			}

			ResultSet result = stmt.getResultSet();
			while (result.next()) {
				if (!PRUSSIA_FIRST || result.getString("staat_name") != "Preu en") {
					State state = new State(result.getInt("staat_id"));
					state.setStaat_name(result.getString("staat_name"));
					states.add(state);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return states;
	}

	private static void cleanUp(String theCase, String tableAppendix) throws SQLException {
		Connection conn = connect();
		for (int run = 1; run <= 100; run++) {
			List<String> tables = new ArrayList<String>();
			tables.add("case_" + tableAppendix + theCase + "_tariff_random_" + String.valueOf(run));
			tables.add("case_" + tableAppendix + theCase + "_demand_random_" + String.valueOf(run));
			tables.add("case_" + tableAppendix + theCase + "_optimal_random_" + String.valueOf(run));
			for (String table : tables) {
				System.out.println("Deleting " + table);
				PreparedStatement stmt = conn.prepareStatement("DROP TABLE IF EXISTS " + table + ";");
				stmt.execute();
			}
		}

	}
	
	public static double change(double old, double by)
	{
		return (1.0d+by)*old;		
	}
}