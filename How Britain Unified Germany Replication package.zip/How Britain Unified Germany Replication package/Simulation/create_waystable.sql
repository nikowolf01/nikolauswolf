/* REPLACE WAYSTABLE AND STATESTABLE */

CREATE TABLE public.WAYSTABLE
(
  gid serial,
  source integer,
  target integer,
  cost double precision,
  rcost double precision,
  type character(3),
  name character varying,
  geom geometry(LineString),
  crosses integer[],
  direct_geom geometry(LineString,32632)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.WAYSTABLE
  OWNER TO postgres;

CREATE INDEX WAYSTABLE_geom_gidx
  ON public.WAYSTABLE
  USING gist
  (geom);

CREATE INDEX WAYSTABLE_gid_idx
  ON public.WAYSTABLE
  USING btree
  (gid);

CREATE INDEX WAYSTABLE_source_idx
  ON public.WAYSTABLE
  USING btree
  (source);


CREATE INDEX WAYSTABLE_target_idx
  ON public.WAYSTABLE
  USING btree
  (target);

CREATE INDEX WAYSTABLE_type_idx
  ON public.WAYSTABLE
  USING btree
  (type COLLATE pg_catalog."default");

UPDATE STATESTABLE SET reg_geom=st_makevalid(reg_geom);

DELETE FROM WAYSTABLE;

INSERT INTO WAYSTABLE(type,name,geom)
SELECT 'C2C',s1.hauptstadt||'<-->'||s2.hauptstadt,st_makeline(s1.city_geom,s2.city_geom) FROM STATESTABLE s1 JOIN STATESTABLE s2 ON s1.gid<s2.gid AND st_distance(s1.city_geom,s2.city_geom)<200000;

UPDATE WAYSTABLE SET cost=1.2*(st_length(geom)/1000),rcost=1.2*(st_length(geom)/1000) WHERE type='C2C';

INSERT INTO WAYSTABLE(type,name,geom,crosses)
SELECT 'SEA',s1.hauptstadt||'<-->'||s2.hauptstadt,st_makeline(s1.city_geom,s2.city_geom),ARRAY[s1.staat_id,s2.staat_id] FROM STATESTABLE s1 JOIN STATESTABLE s2 ON s1.harbor AND s2.harbor AND s1<s2;

UPDATE WAYSTABLE SET cost=0.0095*(st_length(geom)/1000),rcost=0.0095*(st_length(geom)/1000) WHERE type='SEA';

INSERT INTO WAYSTABLE(type,name,geom)
SELECT 'PAV',name,geom FROM network_streets2;

UPDATE WAYSTABLE SET cost=0.3*(st_length(geom)/1000),rcost=0.3*(st_length(geom)/1000) WHERE type='PAV';

INSERT INTO WAYSTABLE(type,name,geom)
SELECT 'RIV',name,geom FROM network_rivers WHERE z_start>z_end;
UPDATE WAYSTABLE SET cost=0.007*(st_length(geom)/1000),rcost=0.018*(st_length(geom)/1000) WHERE type='RIV';

INSERT INTO WAYSTABLE(type,name,geom)
SELECT 'RIV',name,geom FROM network_rivers WHERE z_start<=z_end;
UPDATE WAYSTABLE SET rcost=0.007*(st_length(geom)/1000),cost=0.018*(st_length(geom)/1000) WHERE type='RIV' AND cost IS NULL;

SELECT pgr_createTopology('WAYSTABLE', 3000, 'geom', 'gid', 'source','target','TRUE', TRUE);

UPDATE STATESTABLE SET ways_node=(SELECT id FROM WAYSTABLE_vertices_pgr ORDER BY the_geom<->city_geom LIMIT 1);

WITH crossings AS
(
	SELECT WAYSTABLE.gid,sort(array_agg(staat_id)) AS states_2 FROM WAYSTABLE JOIN STATESTABLE ON st_intersects(geom,reg_geom) GROUP BY WAYSTABLE.gid
)
UPDATE WAYSTABLE SET crosses=(SELECT states_2 FROM crossings WHERE crossings.gid=WAYSTABLE.gid) WHERE type!='SEA';

WITH missing_states_2 AS
(
	SELECT array_agg(WAYSTABLE.gid) AS ways,staat_id FROM STATESTABLE JOIN WAYSTABLE ON target=ways_node WHERE NOT staat_id=ANY(crosses) GROUP BY staat_name,reg_name,staat_id,ways_node
)
UPDATE WAYSTABLE SET crosses=(SELECT array_append(crosses,missing_states_2.staat_id) FROM missing_states_2 WHERE WAYSTABLE.gid=ANY(missing_states_2.ways)) FROM missing_states_2 WHERE WAYSTABLE.gid=ANY(missing_states_2.ways);

UPDATE WAYSTABLE SET direct_geom=st_makeline((SELECT the_geom FROM WAYSTABLE_vertices_pgr WHERE id=source),(SELECT the_geom FROM WAYSTABLE_vertices_pgr WHERE id=target));