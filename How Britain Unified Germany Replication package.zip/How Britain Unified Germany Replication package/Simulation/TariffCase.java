package vienna2;


import java.util.ArrayList;

public class TariffCase
{
	private State state;
	private int period;
	private double tariff;
	private double revenue;
	private ArrayList<Destination> destinations;
	public State getState()
	{
		return state;
	}
	public void setState(State state)
	{
		this.state = state;
	}
	public double getTariff()
	{
		return tariff;
	}
	public void setTariff(double tariff)
	{
		this.tariff = tariff;
	}
	public double getRevenue()
	{
		return revenue;
	}
	public void setRevenue(double revenue)
	{
		this.revenue = revenue;
	}
	public ArrayList<Destination> getDestinations()
	{
		return destinations;
	}
	public void setDestinations(ArrayList<Destination> destinations)
	{
		this.destinations = destinations;
	}
	public int getPeriod()
	{
		return period;
	}
	public void setPeriod(int period)
	{
		this.period = period;
	}
}
