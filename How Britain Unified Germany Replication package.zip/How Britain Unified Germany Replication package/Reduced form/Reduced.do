use Reduced.dta, clear
drop if joined>2000 //Top coded at 9999.
drop if staat_name=="Preußen"

egen pop_std = std(pop)
egen distancetooceans_std=std(distancetooceans)

label var hasharbor "Sea harbor"
label var transitsprussia "Transits Prussia"
label var pop_std "Population (std.)"
label var joined "Year of joining"
label var absolutemonarchy "Absolute monarchy"
label var distancetooceans_std "Distance to oceans (std.)"

stset joined

reg joined distancetooceans_std, robust
outreg2 using reduced.tex, replace label
stcox distancetooceans_std, robust
outreg2 using reduced_cox.tex, replace label addstat(Pseudo R2, e(r2_p))

reg joined transitsprussia, robust
outreg2 using reduced.tex, append label
stcox transitsprussia, robust
outreg2 using reduced_cox.tex, append label eform cti(hr) addstat(Pseudo R2, e(r2_p))

reg joined distancetooceans_std transitsprussia, robust
outreg2 using reduced.tex, append label
stcox distancetooceans_std transitsprussia, robust
outreg2 using reduced_cox.tex, append label eform cti(hr) addstat(Pseudo R2, e(r2_p))

reg joined distancetooceans_std transitsprussia hasharbor, robust
outreg2 using reduced.tex, append label
stcox distancetooceans_std transitsprussia hasharbor, robust
outreg2 using reduced_cox.tex, append label eform cti(hr) addstat(Pseudo R2, e(r2_p))

reg joined c.transitsprussia##c.distancetooceans_std, robust
outreg2 using reduced.tex, append label
stcox c.transitsprussia##c.distancetooceans_std, robust
outreg2 using reduced_cox.tex, append label eform cti(hr) addstat(Pseudo R2, e(r2_p))

reg joined c.transitsprussia##c.distancetooceans_std hasharbor, robust
outreg2 using reduced.tex, append label
stcox c.transitsprussia##c.distancetooceans_std hasharbor, robust
outreg2 using reduced_cox.tex, append label eform cti(hr) addstat(Pseudo R2, e(r2_p))

reg joined c.transitsprussia##c.distancetooceans_std hasharbor absolutemonarchy, robust
outreg2 using reduced.tex, append label
stcox c.transitsprussia##c.distancetooceans_std hasharbor absolutemonarchy, robust
outreg2 using reduced_cox.tex, append label eform cti(hr) addstat(Pseudo R2, e(r2_p))

reg joined c.transitsprussia##c.distancetooceans_std hasharbor absolutemonarchy pop_std, robust
outreg2 using reduced.tex, append label
stcox  c.transitsprussia##c.distancetooceans_std hasharbor absolutemonarchy pop_std, robust
outreg2 using reduced_cox.tex, append label eform cti(hr) addstat(Pseudo R2, e(r2_p))